package com.shreesha.mantracount;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int i = 0;
    int targetValue = 0;
    EditText tar;
    Button count, target, reset;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tar = findViewById(R.id.tar);
        count = findViewById(R.id.count);
        target = findViewById(R.id.target);
        reset = findViewById(R.id.reset);

        // Initialize MediaPlayer with the sound file
        mediaPlayer = MediaPlayer.create(this, R.raw.sound);

        // Set click listener for the Count button
        count.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i++;
                count.setText(String.valueOf(i));

                // Check if the target value is reached and trigger alarm and vibration
                if (targetValue > 0 && i == targetValue) {
                    triggerAlarmAndVibration();
                }
            }
        });

        // Set click listener for the Target button
        target.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String targetStr = tar.getText().toString();
                if (!targetStr.isEmpty()) {
                    targetValue = Integer.parseInt(targetStr);
                    Toast.makeText(MainActivity.this, "Target set to " + targetValue, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a valid target value.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set click listener for the Reset button
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i = 0;
                targetValue = 0;
                count.setText("Count");
                tar.setText("");
                Toast.makeText(MainActivity.this, "Count and Target reset", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to trigger alarm and vibration
    private void triggerAlarmAndVibration() {
        // Play sound
        if (mediaPlayer != null) {
            mediaPlayer.start();
        }

        // Trigger vibration
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator != null) {
            // Vibrate for 500 milliseconds
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Release the MediaPlayer resources
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
